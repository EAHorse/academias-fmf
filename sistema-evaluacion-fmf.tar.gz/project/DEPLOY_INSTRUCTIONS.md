# Instrucciones de Despliegue en Vercel

## Método 1: Interfaz Web de Vercel (Recomendado)

### Paso 1: Sube tu proyecto a GitHub
1. Ve a https://github.com/new
2. Crea un nuevo repositorio (por ejemplo: "fmf-evaluacion-academias")
3. Sigue las instrucciones para subir tu código:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/TU-REPO.git
   git push -u origin main
   ```

### Paso 2: Conecta con Vercel
1. Ve a https://vercel.com
2. Haz clic en "Sign Up" (puedes usar tu cuenta de GitHub)
3. Haz clic en "Add New Project"
4. Selecciona "Import Git Repository"
5. Autoriza a Vercel para acceder a tu GitHub
6. Selecciona tu repositorio

### Paso 3: Configura el Proyecto
Vercel detectará automáticamente la configuración:
- **Framework Preset:** Vite
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
- **Install Command:** `npm install`

### Paso 4: Agrega Variables de Entorno
Antes de hacer clic en "Deploy", expande "Environment Variables" y agrega:

```
VITE_SUPABASE_URL=https://otljcnburkjxdevyjnsy.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im90bGpjbmJ1cmtqeGRldnlqbnN5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIyNzA3NzksImV4cCI6MjA3Nzg0Njc3OX0.0hzx_DFxma8Uf2KhKN2d8GsSLjtKc-iyeeF5dk5Cejo
```

### Paso 5: Despliega
1. Haz clic en "Deploy"
2. Espera 1-2 minutos
3. ¡Tu app estará en línea!

Tu URL será algo como: `https://tu-proyecto.vercel.app`

---

## Método 2: Vercel CLI

### Instalación
```bash
npm install -g vercel
```

### Despliegue
```bash
# Desde la carpeta del proyecto
vercel

# Sigue las instrucciones en pantalla
# La primera vez te pedirá login y configuración
```

### Para producción
```bash
vercel --prod
```

---

## Características de tu Despliegue

✅ **PWA Instalable:** Los usuarios podrán instalar la app en sus móviles
✅ **Funciona Offline:** Gracias al Service Worker
✅ **HTTPS Automático:** Conexión segura
✅ **CDN Global:** Rápido en todo el mundo
✅ **Actualizaciones Automáticas:** Al hacer push a GitHub

---

## Compartir con tu Equipo

Una vez desplegado, comparte la URL con:
- Administradores (login: admin@fmf.mx / admin123)
- Evaluadores (deben registrarse desde la app)

Los evaluadores pueden:
1. Abrir la URL en su navegador móvil
2. Instalar la app (aparecerá un banner o usar "Añadir a pantalla de inicio")
3. Usar la app como si fuera nativa, incluso offline

---

## Actualizaciones Futuras

Para actualizar la app:
1. Haz cambios en tu código local
2. Haz commit y push a GitHub:
   ```bash
   git add .
   git commit -m "Descripción de cambios"
   git push
   ```
3. Vercel desplegará automáticamente la nueva versión

---

## Soporte

- Documentación Vercel: https://vercel.com/docs
- Supabase Dashboard: https://app.supabase.com
- Tu proyecto Supabase: https://otljcnburkjxdevyjnsy.supabase.co
